// Contour Studio square blank. mm. Free to print, modify and share.
linear_extrude(4) offset(delta=-.1) polygon([[50.0, -50.0], [50.0, 50.0], [-50.0, 50.0], [-50.0, -50.0]]);
