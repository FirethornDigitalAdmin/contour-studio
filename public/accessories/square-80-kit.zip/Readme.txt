Contour Studio square blank + matching base — 80 mm tile system
Blank: 4 mm thick, 0.2 mm edge clearance. Base: 4 mm seat, 3 mm rim, 6 mm tile gap.
Generated with the same modular_holders function used for expandable map tiles.
Rear joining-key sockets and hanging keyhole are included. Print both rear-down.
Blank.stl and Base.stl share an XY origin; in an assembly the blank sits 4 mm above the base.
Use the same size, gap, tolerance and holder dimensions as your existing modular tiles.
Legacy collections and customised holder/magnet settings may differ. These are lift-out seats.
Keys align neighbouring bases. Secure each base independently; keys do not carry hanging loads.
Fit and load performance need physical testing. Choose your own material and slicer settings.
Free to print, modify and share, including commercially.
